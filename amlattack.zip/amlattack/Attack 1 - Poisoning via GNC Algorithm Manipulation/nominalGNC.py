import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import SGDRegressor
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler
import os

data_directory = '/home/aal/cFS/build/exe/cpu1/OnAIR/'

os.chdir(data_directory)

try:
    df = pd.read_csv('dlc.csv', delimiter='\t')  # Assuming tab-delimited data
except FileNotFoundError:
    print("Error: File 'dlc.csv' not found. Please check the file path.")
    exit(1)

df.columns = df.columns.str.strip()

print("Columns in the DataFrame:", df.columns)

selected_columns = [
    'DATA_DELTA_VEL[2]',
    'DATA_DELTA_VEL[3]',
    'DATA_DELTA_ANGLE[1]',
    'DATA_DELTA_ANGLE[2]',
    'DATA_DELTA_ANGLE[3]'
]

missing_columns = [col for col in selected_columns if col not in df.columns]

if missing_columns:
    print(f"Error: The following columns are missing in the DataFrame: {missing_columns}")
    exit(1)

X = df[selected_columns]

y = df['DATA_DELTA_VEL[1]']  # Using 'DATA_DELTA_VEL[1]' as a target variable (example)

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Experiment with learning rates
learning_rates = [0.001, 0.01, 0.1, 0.5]  # list adjusted with different learning rates, poison script is executed to rotate the learning rates

for learning_rate in learning_rates:
    model = SGDRegressor(learning_rate='constant', eta0=learning_rate, random_state=42)
    model.fit(X_train, y_train)

    print(f"\nLearning Rate: {learning_rate}")
    print("Coefficients:", model.coef_)

    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    print(f'The mean squared error of the model is {mse:.2f} with a learning rate of {learning_rate}.')