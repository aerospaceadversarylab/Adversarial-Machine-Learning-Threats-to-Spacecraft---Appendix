import os
import random
import re

script_path = '/path/to/nominalGNC.py'

with open(script_path, 'r') as file:
    script_content = file.read()

pattern = r"learning_rates = \[(.*?)\]"

matches = re.findall(pattern, script_content)
if matches:
    learning_rates_line = matches[0]
    learning_rates = [float(rate.strip()) for rate in learning_rates_line.split(',')]

    random_learning_rates = [random.uniform(0.5, 0.9) for _ in learning_rates]

    modified_content = re.sub(pattern, f"learning_rates = {random_learning_rates}", script_content)

    with open(script_path, 'w') as file:
        file.write(modified_content)
else:
    print("target doesn't employ learning rate.")
