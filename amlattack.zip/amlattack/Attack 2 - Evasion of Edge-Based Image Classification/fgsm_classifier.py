import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras import datasets, models

# Load the CIFAR-10 data
(_, _), (test_images, test_labels) = datasets.cifar10.load_data()
test_images = test_images / 255.0

# Load the previously trained model
model = models.load_model('basic_cifar10_model.h5')

def create_adversarial_pattern(input_image, input_label):
    with tf.GradientTape() as tape:
        tape.watch(input_image)
        prediction = model(input_image)
        loss = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True)(input_label, prediction)
    gradient = tape.gradient(loss, input_image)
    signed_grad = tf.sign(gradient)
    return signed_grad

def evaluate_model_on_adversarial_images(model, images, labels, epsilon):
    adv_images = generate_adversarial_images(model, images, labels, epsilon)
    loss, accuracy = model.evaluate(adv_images, labels, verbose=0)
    return accuracy

def generate_adversarial_images(model, images, labels, epsilon=0.01):
    adv_images = []
    for img, label in zip(images, labels):
        img = tf.convert_to_tensor([img], dtype=tf.float32)
        label = tf.convert_to_tensor([label], dtype=tf.int64)
        perturbations = create_adversarial_pattern(img, label)
        adv_img = img + epsilon * perturbations
        adv_images.append(adv_img[0].numpy())
    return np.array(adv_images)

# Select a subset of the test set to evaluate on
num_images = 100
subset_test_images = test_images[:num_images]
subset_test_labels = test_labels[:num_images]

# Vary epsilon and evaluate model
epsilons = [0, 0.005, 0.01, 0.02, 0.05]
accuracies = []

for epsilon in epsilons:
    accuracy = evaluate_model_on_adversarial_images(model, subset_test_images, subset_test_labels, epsilon)
    accuracies.append(accuracy)

# Plotting the graph
plt.figure(figsize=(8, 6))
plt.plot(epsilons, accuracies, marker='o', linestyle='-', color='b')
plt.xlabel('Epsilon (Perturbation Magnitude)')
plt.ylabel('Accuracy')
plt.grid(True)
plt.show()
